/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.al100;

/**
 *
 * @author 50497
 */
public class App {

    public static void main(String[] args) {
   
        for (int i = 2; i <= 100; i += 2) {
            System.out.println(i);
        }
    }
}

